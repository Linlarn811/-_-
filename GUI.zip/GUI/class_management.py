import sys
import pyodbc
from connect_database import connect_to_database
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QLineEdit, QPushButton, QLabel, QMenu, QInputDialog, QMessageBox
)
from PyQt5.QtCore import Qt


class ViewClassesWidget(QWidget):
    def __init__(self, cursor):
        super().__init__()
        self.cursor = cursor
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("班级信息查看")
        self.resize(800, 600)

        # 创建主布局
        main_layout = QVBoxLayout()

        # 搜索框布局
        search_layout = QHBoxLayout()
        id_search_label = QLabel("班级ID：")
        self.id_search_input = QLineEdit()
        name_search_label = QLabel("班级名称：")
        self.name_search_input = QLineEdit()
        self.search_button = QPushButton("搜索")
        self.search_button.clicked.connect(self.search_classes)

        search_layout.addWidget(id_search_label)
        search_layout.addWidget(self.id_search_input)
        search_layout.addWidget(name_search_label)
        search_layout.addWidget(self.name_search_input)
        search_layout.addWidget(self.search_button)

        # 添加班级按钮
        self.add_button = QPushButton("添加班级")
        self.add_button.setFixedSize(100, 30)  # 设置按钮尺寸
        self.add_button.clicked.connect(self.create_class)

        # 表格显示
        self.table = QTableWidget()
        self.table.setColumnCount(2)  # 两列：班级ID和班级名称
        self.table.setHorizontalHeaderLabels(["班级ID", "班级名称"])
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)  # 禁止编辑
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        # 将布局添加到主布局
        main_layout.addLayout(search_layout)
        main_layout.addWidget(self.add_button)
        main_layout.addWidget(self.table)

        # 设置主布局
        self.setLayout(main_layout)

        # 加载所有班级信息
        self.load_all_classes()

    def load_all_classes(self):
        """加载所有班级信息到表格中"""
        query = "SELECT class_id, class_name FROM Class"
        try:
            self.cursor.execute(query)
            classes = self.cursor.fetchall()

            self.table.setRowCount(len(classes))  # 设置表格行数
            for row, class_ in enumerate(classes):
                self.table.setItem(row, 0, QTableWidgetItem(str(class_[0])))  # class_id
                self.table.setItem(row, 1, QTableWidgetItem(class_[1]))      # class_name
        except Exception as e:
            print(f"加载班级信息失败：{e}")

    def search_classes(self):
        """根据输入框内容搜索班级"""
        id_text = self.id_search_input.text().strip()
        name_text = self.name_search_input.text().strip()

        if not id_text and not name_text:
            # 如果两个搜索框都为空，显示所有班级
            self.load_all_classes()
            return

        try:
            if id_text and id_text.isdigit():  # 如果输入了班级ID
                query = "SELECT class_id, class_name FROM Class WHERE class_id = ?"
                self.cursor.execute(query, (int(id_text),))
            elif name_text:  # 如果输入了班级名称
                query = "SELECT class_id, class_name FROM Class WHERE class_name LIKE ?"
                self.cursor.execute(query, (f"%{name_text}%",))
            else:
                QMessageBox.warning(self, "无效输入", "班级ID应为整数！")
                return

            results = self.cursor.fetchall()
            self.table.setRowCount(len(results))  # 设置表格行数
            for row, class_ in enumerate(results):
                self.table.setItem(row, 0, QTableWidgetItem(str(class_[0])))  # class_id
                self.table.setItem(row, 1, QTableWidgetItem(class_[1]))      # class_name

        except Exception as e:
            print(f"搜索班级信息失败：{e}")

    def create_class(self):
        """创建班级（班级号自动生成）"""
        try:
            # 获取最大班级ID，自动生成下一个班级ID
            query = "SELECT MAX(class_id) FROM Class"
            self.cursor.execute(query)
            max_id = self.cursor.fetchone()[0]
            next_id = max_id + 1 if max_id else 1

            # 获取班级名称
            class_name, ok = QInputDialog.getText(self, "添加班级", f"班级ID：{next_id}\n请输入班级名称：")
            if not ok or not class_name.strip():
                return  # 用户取消或输入为空

            # 插入新班级到数据库
            insert_query = "INSERT INTO Class (class_id, class_name) VALUES (?, ?)"
            self.cursor.execute(insert_query, (next_id, class_name.strip()))
            self.cursor.connection.commit()

            QMessageBox.information(self, "成功", "班级添加成功！")
            self.load_all_classes()  # 重新加载表格
        except pyodbc.IntegrityError:
            QMessageBox.critical(self, "错误", "班级ID已存在，无法添加！")
        except Exception as e:
            QMessageBox.critical(self, "错误", f"班级添加失败：{e}")

    def show_context_menu(self, position):
        """右键菜单功能"""
        menu = QMenu()

        delete_action = menu.addAction("删除班级")
        update_action = menu.addAction("修改班级信息")
        cancel_action = menu.addAction("取消")

        action = menu.exec_(self.table.mapToGlobal(position))
        if action == delete_action:
            self.delete_class()
        elif action == update_action:
            self.update_class()

    def delete_class(self):
        """删除选中的班级"""
        row = self.table.currentRow()
        if row == -1:
            QMessageBox.warning(self, "错误", "请先选择要删除的班级！")
            return

        class_id = self.table.item(row, 0).text()
        try:
            # 将关联的学生 class_id 设置为 NULL
            update_students_query = "UPDATE Student SET class_id = NULL WHERE class_id = ?"
            self.cursor.execute(update_students_query, (class_id,))

            # 删除班级
            delete_class_query = "DELETE FROM Class WHERE class_id = ?"
            self.cursor.execute(delete_class_query, (class_id,))
            self.cursor.connection.commit()

            QMessageBox.information(self, "成功", "班级删除成功！")
            self.load_all_classes()
        except Exception as e:
            QMessageBox.critical(self, "错误", f"删除班级失败：{e}")

    def update_class(self):
        """修改选中的班级信息"""
        row = self.table.currentRow()
        if row == -1:
            QMessageBox.warning(self, "错误", "请先选择要修改的班级！")
            return

        class_id = self.table.item(row, 0).text()
        current_name = self.table.item(row, 1).text()

        # 弹出输入框获取新班级名称
        new_name, ok = QInputDialog.getText(self, "修改班级", "输入新的班级名称：", text=current_name)
        if ok and new_name.strip():
            try:
                # 更新班级名称
                query = "UPDATE Class SET class_name = ? WHERE class_id = ?"
                self.cursor.execute(query, (new_name.strip(), class_id))
                self.cursor.connection.commit()
                QMessageBox.information(self, "成功", "班级信息修改成功！")
                self.load_all_classes()
            except Exception as e:
                QMessageBox.critical(self, "错误", f"修改班级失败：{e}")


