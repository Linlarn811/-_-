import sys
import pyodbc
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QComboBox, QPushButton, QLabel, QMenu, QInputDialog, QMessageBox, QDialog, QLineEdit
)
from PyQt5.QtCore import Qt
from connect_database import connect_to_database

class ClassStudentsWidget(QWidget):
    def __init__(self, cursor):
        super().__init__()
        self.cursor = cursor
        self.current_page = 1
        self.page_size = 20  # 每页显示的记录数
        self.total_records = 0
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("查看班级和学生信息")
        self.resize(900, 600)

        # 主布局
        main_layout = QVBoxLayout()

        # 顶部布局：班级选择和按钮
        top_layout = QHBoxLayout()
        self.class_combo = QComboBox()
        self.class_combo.currentIndexChanged.connect(self.load_class_students)
        self.add_student_button = QPushButton("添加学生到班级")
        self.add_student_button.setFixedSize(150, 30)
        self.add_student_button.clicked.connect(self.add_student_dialog)
        top_layout.addWidget(self.class_combo)
        top_layout.addWidget(self.add_student_button)

        # 学生信息表格
        self.table = QTableWidget()
        self.table.setColumnCount(2)  # 学生ID和姓名
        self.table.setHorizontalHeaderLabels(["学生ID", "学生姓名"])
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)  # 禁止编辑
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        # 分页布局
        pagination_layout = QHBoxLayout()
        self.previous_button = QPushButton("上一页")
        self.previous_button.clicked.connect(self.previous_page)
        self.previous_button.setEnabled(False)
        self.page_label = QLabel(f"第 {self.current_page} 页")
        self.next_button = QPushButton("下一页")
        self.next_button.clicked.connect(self.next_page)
        pagination_layout.addWidget(self.previous_button)
        pagination_layout.addWidget(self.page_label)
        pagination_layout.addWidget(self.next_button)

        # 添加到主布局
        main_layout.addLayout(top_layout)
        main_layout.addWidget(self.table)
        main_layout.addLayout(pagination_layout)
        self.setLayout(main_layout)

        # 加载班级信息
        self.load_classes()

    def load_classes(self):
        """加载所有班级信息到下拉框"""
        try:
            query = "SELECT class_id, class_name FROM Class"
            self.cursor.execute(query)
            classes = self.cursor.fetchall()

            self.class_combo.clear()
            for class_ in classes:
                self.class_combo.addItem(f"{class_[0]} - {class_[1]}", class_[0])

        except Exception as e:
            QMessageBox.critical(self, "错误", f"加载班级信息失败：{e}")

    def load_class_students(self):
        """加载选中班级的学生信息"""
        class_id = self.class_combo.currentData()
        if class_id is None:
            return

        try:
            # 获取总记录数
            count_query = "SELECT COUNT(*) FROM Student WHERE class_id = ?"
            self.cursor.execute(count_query, (class_id,))
            self.total_records = self.cursor.fetchone()[0]

            # 计算偏移量
            offset = (self.current_page - 1) * self.page_size
            query = (
                "SELECT student_id, student_name FROM Student WHERE class_id = ? "
                "ORDER BY student_id OFFSET ? ROWS FETCH NEXT ? ROWS ONLY"
            )
            self.cursor.execute(query, (class_id, offset, self.page_size))
            students = self.cursor.fetchall()

            # 填充表格
            self.table.setRowCount(len(students))
            for row, student in enumerate(students):
                self.table.setItem(row, 0, QTableWidgetItem(str(student[0])))
                self.table.setItem(row, 1, QTableWidgetItem(student[1]))

            # 更新分页按钮状态
            self.update_pagination_buttons()

        except Exception as e:
            QMessageBox.critical(self, "错误", f"加载学生信息失败：{e}")

    def update_pagination_buttons(self):
        """更新分页按钮状态和页码标签"""
        self.page_label.setText(f"第 {self.current_page} 页")
        total_pages = (self.total_records + self.page_size - 1) // self.page_size
        self.previous_button.setEnabled(self.current_page > 1)
        self.next_button.setEnabled(self.current_page < total_pages)

    def previous_page(self):
        """上一页"""
        if self.current_page > 1:
            self.current_page -= 1
            self.load_class_students()

    def next_page(self):
        """下一页"""
        total_pages = (self.total_records + self.page_size - 1) // self.page_size
        if self.current_page < total_pages:
            self.current_page += 1
            self.load_class_students()

    def add_student_dialog(self):
        """弹出对话框，添加学生到班级"""
        class_id = self.class_combo.currentData()
        if class_id is None:
            QMessageBox.warning(self, "错误", "请先选择一个班级！")
            return

        dialog = AddStudentDialog(self.cursor, class_id)
        if dialog.exec_():
            QMessageBox.information(self, "成功", "学生已成功加入班级！")
            self.load_class_students()

    def show_context_menu(self, position):
        """右键菜单功能"""
        menu = QMenu()

        transfer_action = menu.addAction("转班")
        remove_action = menu.addAction("踢出学生")
        cancel_action = menu.addAction("取消")

        action = menu.exec_(self.table.mapToGlobal(position))
        if action == transfer_action:
            self.transfer_student_to_class()
        elif action == remove_action:
            self.remove_student_from_class()

    def transfer_student_to_class(self):
        """批量转班操作"""
        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            QMessageBox.warning(self, "错误", "请先选择至少一个学生！")
            return

        dialog = TransferClassDialog(self.cursor)
        if dialog.exec_():
            new_class_id = dialog.selected_class_id
            try:
                student_ids = [int(self.table.item(row.row(), 0).text()) for row in selected_rows]
                query = "UPDATE Student SET class_id = ? WHERE student_id = ?"
                for student_id in student_ids:
                    self.cursor.execute(query, (new_class_id, student_id))

                self.cursor.connection.commit()
                QMessageBox.information(self, "成功", f"{len(student_ids)} 名学生已成功转到班级ID：{new_class_id}！")
                self.load_class_students()
            except Exception as e:
                QMessageBox.critical(self, "错误", f"转班失败：{e}")

    def remove_student_from_class(self):
        """批量踢出学生"""
        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            QMessageBox.warning(self, "错误", "请先选择至少一个学生！")
            return

        try:
            student_ids = [int(self.table.item(row.row(), 0).text()) for row in selected_rows]
            query = "UPDATE Student SET class_id = NULL WHERE student_id = ?"
            for student_id in student_ids:
                self.cursor.execute(query, (student_id,))

            self.cursor.connection.commit()
            QMessageBox.information(self, "成功", f"已成功踢出 {len(student_ids)} 名学生！")
            self.load_class_students()
        except Exception as e:
            QMessageBox.critical(self, "错误", f"踢出学生失败：{e}")


class AddStudentDialog(QDialog):
    """添加学生对话框"""
    def __init__(self, cursor, class_id):
        super().__init__()
        self.cursor = cursor
        self.class_id = class_id
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("添加学生到班级")
        self.resize(600, 400)

        layout = QVBoxLayout()

        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("搜索学生名或学生ID")
        self.search_box.textChanged.connect(self.load_students)
        layout.addWidget(self.search_box)

        self.student_list = QTableWidget()
        self.student_list.setColumnCount(2)
        self.student_list.setHorizontalHeaderLabels(["学生ID", "学生姓名"])
        self.student_list.setEditTriggers(QTableWidget.NoEditTriggers)
        layout.addWidget(self.student_list)

        add_button = QPushButton("添加选中学生")
        add_button.clicked.connect(self.add_students)
        layout.addWidget(add_button)

        self.setLayout(layout)
        self.load_students()

    def load_students(self):
        search_text = self.search_box.text().strip()
        try:
            query = "SELECT student_id, student_name FROM Student WHERE class_id IS NULL"
            if search_text:
                query += " AND (student_id LIKE ? OR student_name LIKE ?)"
                self.cursor.execute(query, (f"%{search_text}%", f"%{search_text}%"))
            else:
                self.cursor.execute(query)

            students = self.cursor.fetchall()
            self.student_list.setRowCount(len(students))
            for row, student in enumerate(students):
                self.student_list.setItem(row, 0, QTableWidgetItem(str(student[0])))
                self.student_list.setItem(row, 1, QTableWidgetItem(student[1]))
        except Exception as e:
            QMessageBox.critical(self, "错误", f"加载学生失败：{e}")

    def add_students(self):
        selected_rows = self.student_list.selectionModel().selectedRows()
        if not selected_rows:
            QMessageBox.warning(self, "错误", "请先选择至少一个学生！")
            return

        try:
            for row in selected_rows:
                student_id = int(self.student_list.item(row.row(), 0).text())
                query = "UPDATE Student SET class_id = ? WHERE student_id = ?"
                self.cursor.execute(query, (self.class_id, student_id))

            self.cursor.connection.commit()
            QMessageBox.information(self, "成功", "学生已成功加入班级！")
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "错误", f"添加学生失败：{e}")


class TransferClassDialog(QDialog):
    """转班对话框"""
    def __init__(self, cursor):
        super().__init__()
        self.cursor = cursor
        self.selected_class_id = None
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("选择转班班级")
        self.resize(400, 300)

        layout = QVBoxLayout()

        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("搜索班级名或班级ID")
        self.search_box.textChanged.connect(self.load_classes)
        layout.addWidget(self.search_box)

        self.class_list = QTableWidget()
        self.class_list.setColumnCount(2)
        self.class_list.setHorizontalHeaderLabels(["班级ID", "班级名称"])
        self.class_list.setEditTriggers(QTableWidget.NoEditTriggers)
        layout.addWidget(self.class_list)

        select_button = QPushButton("选择")
        select_button.clicked.connect(self.select_class)
        layout.addWidget(select_button)

        self.setLayout(layout)
        self.load_classes()

    def load_classes(self):
        search_text = self.search_box.text().strip()
        try:
            query = "SELECT class_id, class_name FROM Class"
            if search_text:
                query += " WHERE class_id LIKE ? OR class_name LIKE ?"
                self.cursor.execute(query, (f"%{search_text}%", f"%{search_text}%"))
            else:
                self.cursor.execute(query)

            classes = self.cursor.fetchall()
            self.class_list.setRowCount(len(classes))
            for row, class_ in enumerate(classes):
                self.class_list.setItem(row, 0, QTableWidgetItem(str(class_[0])))
                self.class_list.setItem(row, 1, QTableWidgetItem(class_[1]))
        except Exception as e:
            QMessageBox.critical(self, "错误", f"加载班级失败：{e}")

    def select_class(self):
        row = self.class_list.currentRow()
        if row == -1:
            QMessageBox.warning(self, "错误", "请先选择一个班级！")
            return

        self.selected_class_id = int(self.class_list.item(row, 0).text())
        self.accept()

#
# if __name__ == "__main__":
#     # 连接到数据库
#
#
#     connection = connect_to_database()
#     cursor = connection.cursor()
#
#     # 启动应用程序
#     app = QApplication(sys.argv)
#     window = ClassStudentsWidget(cursor)
#     window.show()
#     sys.exit(app.exec_())
