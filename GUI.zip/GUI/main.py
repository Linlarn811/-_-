import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox
from administer import Ui_MainWindow  # 导入通过 pyuic5 转换生成的界面类
from class_management import ViewClassesWidget  # 导入班级查看窗口
from connect_database import connect_to_database  # 导入数据库连接函数
from class_student import ClassStudentsWidget

class MainWindow(QMainWindow):
    def __init__(self, cursor):
        super(MainWindow, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.cursor = cursor

        # 连接 ComboBox 的选项选择信号
        self.ui.comboBox.currentIndexChanged.connect(self.handle_combobox_selection)

    def handle_combobox_selection(self, index):
        """处理 ComboBox 的选项选择"""
        if index == 1:  # 如果选择了 "查看班级"
            self.open_view_classes()
        elif index == 2:  # 如果选择了 "创建班级"
            self.open_class_student()
        else:
            print("选择了其他模块或未选择有效选项。")

    def open_view_classes(self):
        """打开班级查看窗口"""
        self.view_classes_window = ViewClassesWidget(self.cursor)
        self.view_classes_window.show()
    def open_class_student(self):
        self.view_class_student_window=ClassStudentsWidget(self.cursor)
        self.view_class_student_window.show()

if __name__ == "__main__":
    # 连接到数据库
    connection = connect_to_database()
    cursor = connection.cursor()

    # 创建应用程序实例
    app = QApplication(sys.argv)
    main_window = MainWindow(cursor)  # 传递数据库游标
    main_window.show()
    sys.exit(app.exec_())
